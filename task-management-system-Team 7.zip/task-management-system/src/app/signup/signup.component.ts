import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})

  export class SignupComponent {
    email = '';
    password = '';
    error = '';
  
    constructor(private authService: AuthService, private router: Router) {}
  
    onSubmit() {
      const user = { email: this.email, password: this.password };
      this.authService.signup(user).subscribe({
        next: () => this.router.navigate(['/login']),
        error: (err) => {
          this.error = 'Signup failed. Please try again.';
          console.error('Signup error:', err);
        }
      });
    }
  }
