import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';
import { TaskService } from '../task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  tasks: any[] = [];
  newTask = { title: '', description: '', category: 'Work', priority: 'Medium', dueDate: '' };

  constructor(
    private authService: AuthService, // Keep private
    private taskService: TaskService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadTasks();
  }

  get userEmail(): string {
    return this.authService.getCurrentUser().email; // Public getter
  }

  loadTasks() {
    this.taskService.getTasks().subscribe(tasks => (this.tasks = tasks));
  }

  addTask() {
    this.taskService.addTask(this.newTask).subscribe(() => {
      this.loadTasks();
      this.newTask = { title: '', description: '', category: 'Work', priority: 'Medium', dueDate: '' };
    });
  }

  toggleComplete(task: any) {
    task.completed = !task.completed;
    this.taskService.updateTask(task).subscribe(() => this.loadTasks());
  }

  deleteTask(id: number) {
    this.taskService.deleteTask(id).subscribe(() => this.loadTasks());
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  toggleTheme() {
    document.body.classList.toggle('dark-mode');
  }
}