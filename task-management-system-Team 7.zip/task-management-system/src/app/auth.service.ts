import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators'; // Import tap and catchError

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:3000/users';
  private loggedInUser: any = null;

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}?email=${email}&password=${password}`).pipe(
      tap((users: any[]) => { // Specify type for users
        if (users.length > 0) {
          this.loggedInUser = users[0];
          localStorage.setItem('user', JSON.stringify(this.loggedInUser));
        }
      }),
      catchError(error => {
        console.error('Login failed:', error);
        throw error;
      })
    );
  }

  signup(user: any): Observable<any> {
    return this.http.post(this.apiUrl, user).pipe(
      tap(() => console.log('User signed up successfully')),
      catchError(error => {
        console.error('Signup failed:', error);
        throw error;
      })
    );
  }

  logout() {
    this.loggedInUser = null;
    localStorage.removeItem('user');
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('user');
  }

  getCurrentUser() {
    return JSON.parse(localStorage.getItem('user') || '{}');
  }
}
